public class Main {
    public static void main(String[] args) {
        // Membuat objek Student
        Student student = new Student("John", "123 Main St, Anytown USA", "Computer Science", 3, 3000.0);
        System.out.println(student.getName()); // John
        System.out.println(student.getAddress()); // 123 Main St, Anytown USA
        System.out.println(student.getProgram()); // Computer Science
        System.out.println(student.getYear()); // 3
        System.out.println(student.getFee()); // 3000.0
        System.out.println(student.toString()); // Student[Person[name=John, address=123 Main St, Anytown USA], program=Computer Science, year=3, fee=3000.0]

        // Membuat objek Staff
        Staff staff = new Staff("Jane", "456 Oak St, Anytown USA", "ABC School", 5000.0);
        System.out.println(staff.getName()); // Jane
        System.out.println(staff.getAddress()); // 456 Oak St, Anytown USA
        System.out.println(staff.getSchool()); // ABC School
        System.out.println(staff.getPay()); // 5000.0
        System.out.println(staff.toString());
    }
}