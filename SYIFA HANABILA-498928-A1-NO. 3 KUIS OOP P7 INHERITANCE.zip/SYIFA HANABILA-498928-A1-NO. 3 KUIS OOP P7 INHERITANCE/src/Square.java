public class Square extends Rectangle{
    public Square() {
        super();
    }

    public Square(double side) {
        super(side, side);
    }

    public Square(double side, String color, boolean filled) {
        super(side, side, color, filled);
    }

    public double getSide() {
        return super.getWidth(); // atau super.getLength()
    }

    public void setSide(double side) {
        super.setWidth(side);
        super.setLength(side);
    }

    @Override
    public void setWidth(double width) {
        setSide(width);
    }

    @Override
    public void setLength(double length) {
        setSide(length);
    }

    @Override
    public double getArea() {
        double side = super.getWidth(); // atau super.getLength()
        return side * side;
    }

    @Override
    public double getPerimeter() {
        double side = super.getWidth(); // atau super.getLength()
        return 4 * side;
    }
    //method getArea() dan getPerimeter() perlu di-override pada kelas tambahan Square karena bentuk Square berbeda dengan Rectangle.
    //Pada method getArea(), perhitungannya berbeda karena Square memiliki sisi yang sama panjang, dengan rumus sisi x sisi. Sedangkan Rectangle, rumusnya panjang x lebar.
    //Pada method getPerimeter(), perhitungannya juga berbeda karena Square memiliki rumus 4 x sisi. Sedangkan Rectangle, rumusnya adalah 2 x (panjang + lebar).


    @Override
    public String toString() {
        return "Square[" + super.toString() + "]";
    }
}
