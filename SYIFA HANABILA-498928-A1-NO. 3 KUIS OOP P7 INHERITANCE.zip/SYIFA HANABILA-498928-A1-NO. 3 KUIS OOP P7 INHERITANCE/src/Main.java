public class Main {
    public static void main(String[] args) {

        //objek Shape
        Shape shape1 = new Shape();
        System.out.println("Shape :");
        System.out.println("Color: " + shape1.getColor());
        System.out.println("Filled: " + shape1.isFilled());
        shape1.setColor("blue");
        shape1.setFilled(false);
        System.out.println("New color: " + shape1.getColor());
        System.out.println("New filled: " + shape1.isFilled());
        System.out.println(shape1.toString());
        System.out.println();

        //objek Circle
        Circle circle1 = new Circle();
        System.out.println("Circle :");
        System.out.println("Color: " + circle1.getColor());
        System.out.println("Filled: " + circle1.isFilled());
        System.out.println("Radius: " + circle1.getRadius());
        circle1.setColor("green");
        circle1.setFilled(true);
        circle1.setRadius(2.0);
        System.out.println("New color: " + circle1.getColor());
        System.out.println("New filled: " + circle1.isFilled());
        System.out.println("New radius: " + circle1.getRadius());
        System.out.println("Area: " + circle1.getArea());
        System.out.println("Perimeter: " + circle1.getPerimeter());
        System.out.println(circle1.toString());
        System.out.println();

        //objek Rectangle
        Rectangle rectangle1 = new Rectangle();
        System.out.println("Rectangle :");
        System.out.println("Color: " + rectangle1.getColor());
        System.out.println("Filled: " + rectangle1.isFilled());
        System.out.println("Width: " + rectangle1.getWidth());
        System.out.println("Length: " + rectangle1.getLength());
        rectangle1.setColor("yellow");
        rectangle1.setFilled(false);
        rectangle1.setWidth(2.0);
        rectangle1.setLength(3.0);
        System.out.println("New color: " + rectangle1.getColor());
        System.out.println("New filled: " + rectangle1.isFilled());
        System.out.println("New width: " + rectangle1.getWidth());
        System.out.println("New length: " + rectangle1.getLength());
        System.out.println("Area: " + rectangle1.getArea());
        System.out.println("Perimeter: " + rectangle1.getPerimeter());
        System.out.println(rectangle1.toString());
        System.out.println();

        //objek Square
        Square square1 = new Square();
        System.out.println("Square :");
        System.out.println("Color: " + square1.getColor());
        System.out.println("Filled: " + square1.isFilled());
        System.out.println("Width: " + square1.getWidth());
        System.out.println("Length: " + square1.getLength());
        System.out.println("Side: " + square1.getSide());
        square1.setColor("purple");
        square1.setFilled(true);
        square1.setSide(2.0);
        System.out.println("New color: " + square1.getColor());
        System.out.println("New filled: " + square1.isFilled());
        System.out.println("New side: " + square1.getSide());
        System.out.println("Area: " + square1.getArea());
        System.out.println("Perimeter: " + square1.getPerimeter());
        System.out.println(square1.toString());
        System.out.println();
    }
}